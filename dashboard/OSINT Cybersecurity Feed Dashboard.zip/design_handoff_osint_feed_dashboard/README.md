# Handoff: OSINT Cybersecurity Feed Dashboard

## Overview
A live-monitoring dashboard styled after a SOC/terminal tool. It aggregates posts from Reddit security subs and a cybersecurity news RSS feed into one scrolling feed, with sidebar source/topic stats. No CVE tracking feature, no severity scoring, no X/Facebook/Bluesky sources — data model is Reddit + news RSS only.

## About the Design Files
The bundled `OSINT Feed Dashboard.dc.html` is a **design reference prototype** built in HTML/JS (a "Design Component" — plain HTML with an embedded vanilla-JS-ish component runtime, not a framework). It is not production code to copy verbatim. Recreate this UI in your target codebase's existing stack (React, Vue, Swift, etc.) using its established patterns, component library, and data layer. If no stack exists yet, React is a natural fit given the component boundaries described below.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy are final. Layout, interaction, and animation behavior should be recreated precisely; wire in real data in place of the static/simulated dataset.

## Screens / Views
Single screen, four regions in a CSS grid: `250px 1fr 320px` columns × `52px 1fr` rows.

### Top bar (row 1, full width)
- Height 52px, background `--bg-panel`, bottom border `--border`.
- Left: status dot (8px circle, blinking `opacity 1↔0.25` over 1.6s when live, solid amber when paused) + label "OSINT//WATCH" (13px, weight 700, letter-spacing .12em; "//" in green).
- Divider, then a stats row (11.5px, `--text-dim`): `UPTIME hh:mm:ss`, `COLLECTED <n>`, `RATE <n>/min`, and — only when a filter is active — `FILTER <label> [clear]`.
- Right: PAUSE/RESUME button (11px, weight 700, letter-spacing .08em, bordered, no radius). Currently pauses the relative-timestamp clock (data itself is a static snapshot, not live-polled).

### Left sidebar (row 2, col 1, 250px)
- Background `--bg-panel`, right border `--border`.
- Header "ACTIVE SOURCES" (10.5px, weight 700, letter-spacing .14em, `--text-dim2`).
- One row per source: `r/netsec`, `r/cybersecurity`, `r/hacking`, `r/AskNetsec`, "Cybersecurity News RSS". Each row: marker (`>` green when selected / `·` dim otherwise), label, live count (green, right-aligned). Click toggles that source as the feed filter; selected row gets `--bg-elev` background and the `>` marker.
- Footer note describing data sources (small, dim, 3 lines).

### Center feed (row 2, col 2, scrollable)
- Search input ("grep feed…") at top: full width, monospace, 12px.
- Each post card: `--bg-panel` background, 1px `--border`, 10px bottom margin, 12/14px padding.
  - Row 1: source badge (10.5px, weight 700, letter-spacing .08em; green text/bg for Reddit, amber for News) + relative timestamp, German-style ("vor 16s" / "vor 4m" / "vor 2h"), right-aligned, `--text-dim2`.
  - Title: 14px, weight 600.
  - Excerpt: 12px, `--text-dim`, line-height 1.55.
  - Footer row: topic tag (10px amber outline chip) + "View Source →" link (11.5px, dotted underline).
  - New card entrance: `slideIn` keyframe (translateY -6px + fade, 0.3s ease) — only used when a card is freshly inserted at position 0.
  - Keyword matches inside title/excerpt are highlighted: green text on translucent green background, bold, clickable (toggles that keyword as a feed filter). Selected keyword inverts to solid green background / bg-color text.
  - Empty state: centered dim text "// no transmissions match current filter".

### Right sidebar (row 2, col 3, 320px, scrollable)
- Background `--bg-panel`, left border `--border`.
- "VOLUME BY SOURCE": one bar per source — label + count (green) over a 5px track, green fill sized to `count / max(count) * 100%`.
- "VOLUME BY TOPIC": same pattern in amber, one bar per topic category: **Vulnerabilities/Exploits, Network Security, Career/Advice, Tools & Scripts** (only these four — do not add ransomware/phishing/etc. as separate topic-chart buckets; that's an explicit content decision).
- "INGEST RATE": big green number (26px, weight 700) + "posts / min" label — count of posts timestamped within the last 60s.

## Interactions & Behavior
- **Source filter**: click a sidebar source row to filter the feed to that source; click again to clear. Only one source active at a time.
- **Keyword filter**: click any highlighted keyword span in a post to filter the feed to posts containing that keyword (case-insensitive whole-word match). Click the same keyword again to clear.
- **Search box**: free-text substring filter over title + excerpt, combinable with source/keyword filters.
- **Active filter chips**: combined into one string in the top bar (`source + keyword + "query"`), with a `[clear]` link that resets all three filters at once.
- **Pause/Resume**: toggles whether the relative-time clock ticks (labels stop updating when paused); status dot switches from blinking green to solid amber.
- No hover states beyond default link underline/color change (`a:hover` → amber) — add subtle hover backgrounds on clickable rows/spans in the real implementation for affordance.

## State Management
- `posts`: array of `{ id, sourceKey, topic, title, excerpt, ts, url }`. In this prototype it's a static seeded snapshot (20 items, timestamps spread over the last ~50 minutes) — replace with a real fetch from your Reddit + RSS ingestion pipeline, likely appended live in production.
- `selectedSource`, `selectedKeyword`, `searchQuery`: independent, combinable filters (AND logic) applied client-side over `posts`.
- `paused`: boolean, gates the 1s clock tick that re-renders relative timestamps.
- Derived per render: per-source counts, per-topic counts, posts-in-last-60s (rate), and per-post keyword-highlight segments (regex split on a fixed keyword list, word-boundary matched, case-insensitive).

## Design Tokens
Defined as CSS custom properties on the root container:
- `--bg`: `oklch(15% 0.015 250)` — page background
- `--bg-panel`: `oklch(18% 0.016 250)` — panel/card background
- `--bg-elev`: `oklch(22% 0.017 250)` — selected-row background
- `--border`: `oklch(35% 0.02 250 / 0.5)`
- `--text`: `oklch(92% 0.008 250)`
- `--text-dim`: `oklch(62% 0.014 250)`
- `--text-dim2`: `oklch(45% 0.012 250)`
- `--green`: `oklch(78% 0.17 142)`, `--green-dim`: `oklch(45% 0.09 142)`, `--green-bg`: `oklch(78% 0.17 142 / 0.12)`
- `--amber`: `oklch(80% 0.14 70)`, `--amber-dim`: `oklch(48% 0.09 70)`, `--amber-bg`: `oklch(80% 0.14 70 / 0.12)`

Typography: `'JetBrains Mono', ui-monospace, 'SF Mono', Menlo, Consolas, monospace` throughout, loaded from Google Fonts (weights 400/500/600/700). Type scale used: 10px, 10.5px, 11px, 11.5px, 12px, 13px, 14px, 26px.

No border radius anywhere (flat, terminal aesthetic) — do not introduce rounded corners.

## Highlighted keywords
Case-insensitive, whole-word/phrase match: `ransomware, encryption, encrypted, zero-day, rce, remote code execution, exploit, poc, edr, backdoor, c2, botnet, phishing, mfa, credential, credentials, data breach, breach, malware, infostealer, vulnerability, vulnerabilities, apt, nation-state, espionage, ddos, lateral movement, idor, misconfigured, cve`.

## Assets
No external image/icon assets — everything is typographic/CSS (dots, bars, borders). Font: JetBrains Mono via Google Fonts CDN.

## Files
- `OSINT Feed Dashboard.dc.html` — the full design reference (markup + component logic in one file). Open directly in a browser to view/interact with it.
